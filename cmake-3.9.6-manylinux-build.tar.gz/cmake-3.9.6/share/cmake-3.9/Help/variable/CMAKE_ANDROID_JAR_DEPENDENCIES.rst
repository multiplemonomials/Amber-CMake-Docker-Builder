CMAKE_ANDROID_JAR_DEPENDENCIES
------------------------------

Default value for the :prop_tgt:`ANDROID_JAR_DEPENDENCIES` target property.
See that target property for additional information.
