CMAKE_<LANG>_SOURCE_FILE_EXTENSIONS
-----------------------------------

Extensions of source files for the given language.

This is the list of extensions for a given language's source files.
