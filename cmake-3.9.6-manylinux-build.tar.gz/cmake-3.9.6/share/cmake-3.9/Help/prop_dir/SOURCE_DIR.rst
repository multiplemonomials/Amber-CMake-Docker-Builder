SOURCE_DIR
----------

This read-only directory property reports absolute path to the source
directory on which it is read.
